app.controller('ordersCtrl',['$scope','User','$http','$rootScope',function($scope,User,$http,$rootScope) {    /*$scope is the keyword we cant change the keyword*/
    var login={};
    
    
    $http.get('orders/fetch').then(function(response){
               //console.log(response.data);
                $scope.Products=response.data;
                
        });
      //$http.get('orders/checkcart').then(function(response){
      //         //console.log(response.data);
      //          $scope.Products=response.data;
      //          
      //  });
      //
      $scope.product=function(data){
         var id={"id":data};
         $http.post('/orders/product',id).then(function(response){
                              //$rootScope.Product=response.data;
                              $scope.Category=response.data;
                              
                             
                               
                
                
        });
      }
      
        $scope.addcart=function(){
          
        
         $http.post('/orders/addcart',$scope.Category).then(function(response){
                            
                              $scope.cart=response.data;
                              
                             
                               
                
                
        });
      }
      
      
      //  $scope.checkcart=function(){
      //    
      //  
      //   $http.get('/orders/checkcart').then(function(response){
      //                      
      //                        $scope.cart=response.data;
      //                        
      //                       
      //                         
      //          
      //          
      //  });
      //}
     
     
     
      
   
    
    
    
    
}]);