var users=require('../Controller/UsersController.js');
module.exports =users;
