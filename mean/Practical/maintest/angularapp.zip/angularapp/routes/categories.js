var catgory=require('../Controller/CategoriesController.js');
module.exports =catgory;
