
var express = require('express');
var app = express();
var orders = require('../Model/product');
var categories = require('../Model/categories');
var session = require('express-session');

 //Add Orders
 
 
 
 // Listing of Orders
 exports.listingdata=function(req,res){
 
 
    orders.find({}).exec(function(err,result){
  if (err) console.log(err);
  
  res.json(result);
  
  
  
}) ;
 }  
 exports.product=function(data,req,res){
    //if(req.session.userName) {
    //     console.log(req.session.userName);
    //     console.log("Bi");
    //    //code
    //}
    categories.findOne({"path":data}).exec(function(err,result){
  if (err) console.log(err);
  
  res.json(result);
  
  
  
})
 }
 
 exports.addcart=function(data,req,res){
       
       
        
        
       
        carts = new Array();
        oldarray=new Array();
           
        if (req.session.cart == undefined) {
            
            console.log("Here"); 
           carts[0]=data;
           req.session.cart=carts;
          
          
        }else{
           
           oldarray=req.session.cart;
           oldarray.push(data);
           req.session.cart=oldarray;
            
           
          
             
        }
     
        res.json(req.session.cart);
       
    
        
      
       
 
 }
 
 exports.checkcart=function(data,req,res){
       
       
        
        
       
        
           
        if (req.session.cart != undefined) {
         res.json(req.session.cart);
          
          
        }
     
       
       
    
        
      
       
 
 }
 
 ;



