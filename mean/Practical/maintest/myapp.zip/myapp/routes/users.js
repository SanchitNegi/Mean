var user=require('../Controller/UsersController.js');
module.exports =user;